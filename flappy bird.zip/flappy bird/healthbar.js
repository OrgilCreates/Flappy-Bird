function Health_bar(){
this.health = 100;
    
    this.show = function(){
        
        //Red bar behind
        fill(200,0,0);
        rect(width - 130, height - 40, 100,15);
        
        //Green health bar
        fill(0,150,00);
        rect(width - 130, height - 40, this.health,15);
        
        if (this.health <= 0){
            console.log("Game Over!");
        }
    }
}