var bird;
var birdart;
//var birdflap;
var health_bar;
var sky;
var walls = [];

function preload(){
    birdart = loadImage("bird_pic.png");
}
/*
function preload(){
    birdflap = loadImage("bird_flap.png");
}
*/

function setup(){
    
    createCanvas(468,612);
    //Initiate the objects
    bird = new Bird();
    walls.push(new Wall());
    sky = loadImage("sky.png");
    health_bar = new Health_bar();
}

function draw(){
    background(sky);
    
    //ground
    fill(0,100,0);
    rect(0,height-80,width,20);
    fill(180,100,30);
    rect(0,height-60,width,60);
    
    //Rate at which the walls come out
    if (frameCount % 120 == 0){
        walls.push(new Wall());
    }
    
    for (var i = walls.length - 1; i >= 0; i--){
        walls[i].show();
        walls[i].update();
        
        if(frameCount % 10 ==0) {
            if (walls[i].touch(bird)) {
                console.log("Touch");
                
                if(health_bar.health > 0) {
                   health_bar.health -= 20; 
                }
                
            }
        }
            
        
        if(walls[i].off()) {
            walls.splice(i,1);
        }
    }
    
    bird.update();
    bird.show();
    health_bar.show();
}

function keyPressed() {
    if (key == " ") {
        bird.flap();
        //bird.showflap();
    }
}