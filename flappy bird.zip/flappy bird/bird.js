function Bird(){
    
    //position of the bird
    this.y = height/2;
    this.x = 64
    
    //Make it fall
    this.gravity = 0.8;
    this.velocity = 0;
    this.lift = -18;
    
    //Appearance
    this.show = function() {
        image(birdart, this.x, this.y, 50,50);
    }
    /*
    this.show_flap = function() {
        image(birdflap, this.x, this.y, 50,50);
    }
    */
    this.flap = function() {
        this.velocity += this.lift;
    }
    
    this.update = function() {
        this.velocity += this.gravity;
        this.velocity *= 0.9;
        this.y += this.velocity;
        
        //When the bird touches the edge of the screen
        if(this.y > height || this.y < 0) {
            
            this.velocity = 0;
            this.y = height;
            
        }
    }
}


