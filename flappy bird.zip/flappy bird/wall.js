function Wall(){
    this.gap = 140;
    this.gap_pos = random(height * 0.7);
    this.x = width;
    this.w = 30;
    this.speed = 2;
    
    //When the bird collides with the wall
    this.touch = function(bird) {
        if (bird.y < this.gap_pos || bird.y > this.gap_pos + this.gap) {
            if(bird.x > this.x - 25 && bird.x < this.x + this.w) {
                return true;
            }
        }
    }
    
    //Make the walls appear
    this.show = function() {

        fill(30,30,160);
        
    
        rect(this.x, 0, this.w, this.gap_pos);
        rect(this.x, this.gap_pos + this.gap, this.w, height - (this.gap_pos + this.gap + 80));
    }
    
    this.update = function() {
        this.x -= this.speed;
    }
    
    this.off = function() {
        if (this.x < -20) {
            return true;
        }   else {
            return false;
        }
    }
}